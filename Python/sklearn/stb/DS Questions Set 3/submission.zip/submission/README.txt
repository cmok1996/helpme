Pre-requisites:
	Python >= 3.6
	pip install -r requirements.txt

####Description of assets######
Candidate Questions Set 3 - DS.docx : Original questions and answers in red
cluster.py : Script to support Question 1
impute_model.py : Script (model building) to support Question 2
impute.py : Script (imputation of testdata.csv) to support Question 2
impute_model.pkl : sklearn pipeline grid search object
column_dict.pickle : Helper dictionary for column selection
spenddata.csv : Original spend dataset
testdata.csv : Original test dataset
imputed_testdata.csv : testdata.csv with imputed totshopping.rep using impute_model.pkl
	